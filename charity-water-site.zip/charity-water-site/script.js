function donate() {
    alert("Redirecting to the donation page!");
}
